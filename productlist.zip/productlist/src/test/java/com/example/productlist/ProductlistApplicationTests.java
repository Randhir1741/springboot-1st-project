package com.example.productlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductlistApplicationTests {

	@Test
	void contextLoads() {
	}

}
